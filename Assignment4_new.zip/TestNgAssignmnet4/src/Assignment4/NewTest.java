package Assignment4;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest {

public WebDriver driver;

@Test
public void alogin() {
  	driver.get("http://zero.webappsecurity.com/");
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.id("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		driver.findElement(By.name("submit")).click();
	    driver.findElement(By.id("details-button")).click();	  
		driver.findElement(By.id("proceed-link")).click();  	  
		
}
@Test
public void bPay_Bills() {
	    driver.findElement(By.linkText("Pay Bills")).click();
		driver.findElement(By.linkText("Purchase Foreign Currency")).click();
		driver.findElement(By.id("purchase_cash")).click();
		Alert jsAlert = driver.switchTo().alert();
		String alertText = jsAlert.getText();		
		System.out.println("Please, ensure that you have filled all the required fields with valid values. -'"+ alertText + "'");
		jsAlert.accept();		
}

@Test
public void cTransfer_Funds() {
	driver.findElement(By.linkText("Transfer Funds")).click();
	driver.findElement(By.id("tf_amount")).sendKeys("1000");
	driver.findElement(By.id("btn_submit")).click();	
	driver.findElement(By.id("btn_submit")).click();	
	driver.findElement(By.linkText("Zero Bank")).click();
	driver.findElement(By.id("feedback")).click();
	driver.findElement(By.cssSelector("#name")).sendKeys("Garima Kushwah");
	driver.findElement(By.cssSelector("#email[type='text']")).sendKeys("garimakushwah@gmail.com");
	driver.findElement(By.name("subject")).sendKeys("Enquiry");
	driver.findElement(By.name("comment")).sendKeys("Facing issue with login ?");
	driver.findElement(By.name("submit")).click();
}



@BeforeTest(alwaysRun=true)
public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver","c:\\SeleniumBrowserDrivers\\chromedriver.exe");
	 
		// open browser
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	driver.manage().window().maximize();
	
}

@AfterTest
public void afterTest() {
	//Close browser
	     driver.close();
	        
	//kill/quit driver
	       driver.quit();
}

}

