package Assignment4;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest1 {

public WebDriver driver;

@Test(groups= {"regression"})
public void Awrongusermane() 
	  {
	    	driver.get("http://zero.webappsecurity.com/");
			driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.id("user_login")).sendKeys("user");
			driver.findElement(By.id("user_password")).sendKeys("passord");
		driver.findElement(By.name("submit")).click();
			
	  }

@Test
public void Blogin() {
  	    driver.get("http://zero.webappsecurity.com/");
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.id("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		driver.findElement(By.name("submit")).click();
	    driver.findElement(By.id("details-button")).click();	  
		driver.findElement(By.id("proceed-link")).click();  	  		
}
@Test
public void CPay_Bills()  {
	    driver.findElement(By.linkText("Pay Bills")).click();
		driver.findElement(By.linkText("Purchase Foreign Currency")).click();
		driver.findElement(By.id("purchase_cash")).click();
		Alert jsAlert = driver.switchTo().alert();
		String alertText = jsAlert.getText();		
		System.out.println("Please, ensure that you have filled all the required fields with valid values. -'"+ alertText + "'");
		jsAlert.accept();		
}

@Test
public void DTransfer_Funds() {
	driver.findElement(By.linkText("Transfer Funds")).click();
	driver.findElement(By.id("tf_amount")).sendKeys("1000");
	driver.findElement(By.id("btn_submit")).click();	
	driver.findElement(By.id("btn_submit")).click();	
	driver.findElement(By.linkText("Zero Bank")).click();
	driver.findElement(By.id("feedback")).click();
	driver.findElement(By.cssSelector("#name")).sendKeys("Garima Kushwah");
	driver.findElement(By.cssSelector("#email[type='text']")).sendKeys("garimakushwah@gmail.com");
	driver.findElement(By.name("subject")).sendKeys("Enquiry");
	driver.findElement(By.name("comment")).sendKeys("Facing issue with login ?");
	driver.findElement(By.name("submit")).click();
	driver.findElement(By.id("signin_button")).click();
		
}

@Test (groups={"smoke"})
public void FTransfer_Funds() {
	driver.findElement(By.id("onlineBankingMenu")).click();
	driver.findElement(By.id("transfer_funds_link")).click();
	driver.findElement(By.id("tf_amount")).sendKeys("1000");
	driver.findElement(By.id("btn_submit")).click();	
	driver.findElement(By.id("btn_cancel")).click();	
}

@Test
public void GTransfer_Funds() {
	//driver.findElement(By.linkText("Transfer Funds")).click();
	driver.findElement(By.id("tf_amount")).sendKeys("1000");
	driver.findElement(By.id("btn_submit")).click();	
	driver.findElement(By.id("btn_submit")).click();
	
}

@Test
public void JMoneyMap() {	
driver.findElement(By.linkText("My Money Map")).click();
Actions act = new Actions(driver);
WebElement retail = driver.findElement(By.id("ext-sprite-1259"));
WebElement ins = driver.findElement(By.id("ext-sprite-1263"));
act.moveToElement(retail).build().perform();
act.moveToElement(ins).build().perform();

}


@Test(groups= {"regression"})
public void HPay_Saved_Payee()
{
	    driver.findElement(By.linkText("Pay Bills")).click();
	   driver.findElement(By.linkText("Pay Saved Payee")).click();
	    driver.findElement(By.id("pay_saved_payees")).click();			
	//    System.out.println("Test2");	  
}

@Test (groups= {"regression"}) 
public void IPay_Saved_Payee() 
{
	    driver.findElement(By.linkText("Pay Bills")).click();
	    driver.findElement(By.linkText("Pay Saved Payee")).click();
	    driver.findElement(By.id("pay_saved_payees")).click();			
	    driver.findElement(By.id("sp_amount")).sendKeys("1000");
	    driver.findElement(By.id("pay_saved_payees")).click();		    
	    
	 	  
}




@BeforeTest

	  public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver","c:\\SeleniumBrowserDrivers\\chromedriver.exe");
		 
			// open browser
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	  }

@AfterTest
public void afterTest() {
	//Close browser
	     driver.close();
	        
	//kill/quit driver
	       driver.quit();
}

}
